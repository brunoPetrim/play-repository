package play.data.binding;

import java.util.EnumSet;

public class Data5 {

    public enum TestEnum {
        A, B, C, D, E, F
    }

    public String s;
    public EnumSet<TestEnum> testEnumSet;
}
