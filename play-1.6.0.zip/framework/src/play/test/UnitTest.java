package play.test;

public abstract class UnitTest extends BaseTest {

}
